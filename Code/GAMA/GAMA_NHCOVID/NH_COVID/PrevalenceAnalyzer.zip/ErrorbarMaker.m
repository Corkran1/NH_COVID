clear
clc

% % Example matrices (replace these with your actual matrices)
% lowerBounds = rand(14, 6); % Matrix with lower bound values
% meanValues = 20*rand(14, 6);  % Matrix with mean values
% upperBounds = 20*rand(14, 6)+1; % Matrix with upper bound values
load('UpperLowerData.mat')


% this is the order for Figure 5 of the paper
% Alaska 0% column 12
% South Carolina 5% column10
% Nevada 10% column 3
% Kentucky 15% column 1
% Oklahoma 20% column 9
% Georgia 30% column 6

c=6
meanValues=REmeanfromData(:,c);
lowerBounds=RESlowerWhiskerfromData(:,c);
upperBounds=RESupperWhiskerfromData(:,c);
% Calculate the errors
numColumns = size(meanValues, 2); % Number of columns
x = 0:7:7*size(meanValues, 1)-1;       % X-axis values (1 to number of rows)

% Plot the error bars for each column
%figure;
hold on;

for col = 1:1
    % Calculate lower and upper error values for the current column
    lowerErrors = meanValues(:, col) - lowerBounds(:, col);
    upperErrors = upperBounds(:, col) - meanValues(:, col);
    
    % Plot error bars
    errorbar(x, meanValues(:, col), lowerErrors, upperErrors, 'sb', ...
        'DisplayName', ['Column ' num2str(col)]);
end
hold off;

% Add labels, legend, and title
%xlabel('Row Index');
%ylabel('Values');
%title('Error Bars for Each Column');
legend('show');
grid on;
