
function [VQ12,VQ32,VQ1,VQ3,upperWhisker,lowerWhisker,cycle1, Infected_res1, CIr1,  CIs1, PrevRes1, activepositive1, passivepositive1, ...
    cycle2, Infected_res2, CIr2,  CIs2, PrevRes2, activepositive2, passivepositive2] = NHsort(A,sstart,seed,s)
set(0,'defaultAxesFontSize',16)
NH1=56; % number of residents in NH1 
NH2=82; % number of residents in NH2
for i=sstart:seed % these are the min and max of seed numbers
kIndex0=find(A(:,1)==i); %this will find all row numbers of seed i
B=A(kIndex0,:); %this the matrix of seed i
NH1index=find(B(:,3)==0); % these are the rows for NH1
n1=length(NH1index);
NH2index=find(B(:,3)==1); % these are the rows for NH2
n2=length(NH2index);
B1=B(NH1index,:); % this is all data for NH 1 for seed i
B2=B(NH2index,:); % this is all data for NH 2 for seed i
k=i;
for j=1:n1 %each column is one simulation for NH1
    cycle1(j,k)=B1(j,2);
    Infected_res1(j,k)=B1(j,6); % this is number of infected residents 
    CIr1(j,k)=B1(j,7);  %this is the cumulative infected residents
    CIs1(j,k)=B1(j,8);  %this is the cumulative infected staff
    PrevRes1(j,k)=B1(j,10);  %this is the prevalence infected residents
    activepositive1(j,k)=B1(j,12);  %this is number of active postives
    passivepositive1(j,k)=B1(j,14);  %this is number of passive postives
end

for j=1:n2  %each column is one simulation for NH2
    cycle2(j,k)=B2(j,2); % this is number of infection for scenario <5 and prevalance for others
       Infected_res2(j,k)=B2(j,6);
    CIr2(j,k)=B2(j,7);  %this is the cumulative infected residents
    CIs2(j,k)=B2(j,8);  %this is the cumulative infected staff
        PrevRes2(j,k)=B2(j,10);  %this is the cumulative infected residents
     activepositive2(j,k)=B2(j,12);  %this is number of active postives
    passivepositive2(j,k)=B2(j,14);  %this is number of passive postives
end
end
     m=size(cycle1);
 
f1=figure;

C1=100*Infected_res1'/NH1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% here we find the upper/lower whisker values
% Initialize arrays to store the whisker values
lowerWhisker = zeros(size(C1, 2),1);
upperWhisker = zeros(size(C1, 2),1);

% Loop through each column and calculate whisker values
for col = 1:size(C1, 2)
    % Get the current column data
    columnData = C1(:, col);
    
    % Remove NaN values (if any)
    columnData = columnData(~isnan(columnData));
    
    % Calculate the quartiles
    Q1 = prctile(columnData, 25); % 1st quartile
    Q3 = prctile(columnData, 75); % 3rd quartile
    IQR = Q3 - Q1;                % Interquartile range
    
    % Calculate whiskers
    VQ1(col,1) =Q1;
    VQ3(col,1) =Q3;
    lowerWhisker(col,1) = max(min(columnData), Q1 - 1.5 * IQR);
    upperWhisker(col,1) = min(max(columnData), Q3 + 1.5 * IQR);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


boxchart(C1,'WhiskerLineStyle','-','MarkerStyle','none')
xlabel('days')
ylabel('prevalence in NH1 residents')
%set(gca,'xtick',[])
xticks('manual')
xticks(["5","10","15","20","25","30","35","40","45","50","55","60","65","70","75","80","85","90"])
grid on
ylim([0 100])
filename1 = ['NH1ResPrevalence ' num2str(s) ' percent shared' '.tif'];
saveas(gcf,filename1)
filename2 = ['NH1ResPrevalence ' num2str(s) ' percent shared' '.fig'];
saveas(gcf,filename2)
close(f1)

f2=figure;
C2=100*Infected_res1'/NH2;
% Loop through each column and calculate whisker values
for col2 = 1:size(C2, 2)
    % Get the current column data
    columnData2 = C2(:, col2);
    
    % Remove NaN values (if any)
    columnData2 = columnData2(~isnan(columnData2));
    
    % Calculate the quartiles
    Q12 = prctile(columnData2, 25); % 1st quartile
    Q32 = prctile(columnData2, 75); % 3rd quartile
    IQR = Q32 - Q12;                % Interquartile range
    
    % Calculate whiskers
    VQ12(col2,1) =Q12;
    VQ32(col2,1) =Q32;
end



boxchart(C2,'WhiskerLineStyle','-','MarkerStyle','none','BoxFaceColor','red')
xlabel('days')
ylabel('prevalence in NH2 residents')
%set(gca,'xtick',[])
xticks('manual')
xticks(["5","10","15","20","25","30","35","40","45","50","55","60","65","70","75","80","85","90"])
grid on
ylim([0 100])

filenamen1 = ['NH2ResPrevalence ' num2str(s) ' percent shared' '.tif'];
saveas(gcf,filenamen1)
filenamen2 = ['NH2ResPrevalence ' num2str(s) ' percent shared' '.fig'];
saveas(gcf,filenamen2)
close(f2)

Scenario=s;
if Scenario==0  % this is 0 precent shared nurses
disp('statistics for prevalence of infected residents with 0% shared staff')
elseif Scenario==5 % this is 5% precent shared nurses
disp('statistics for prevalence of infected residents with 5% shared staff')
elseif Scenario==10 % this is 10% precent shared nurses
disp('statistics for prevalence of infected residents with 10% shared staff')
elseif Scenario==15 % this is 15% precent shared nurses
disp('statistics for prevalence of infected residents with 15% shared staff') 
elseif Scenario==20 % this is 20% precent shared nurses
disp('statistics for prevalence of infected residents with 20% shared staff') 
elseif Scenario==30 % this is 30% precent shared nurses
disp('statistics for prevalence of infected residents with 30% shared staff')
elseif Scenario==50 % this is 50% precent shared nurses
disp('statistics for prevalence of infected residents with 50% shared staff')
else
disp('Are you drunk?')
end

VecC1 = reshape(C1.',1,[]);
VecC2 = reshape(C2.',1,[]);
NH1_stats = datastats(VecC1') 
NH2_stats = datastats(VecC2') 

