clear
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% this code generates the statsitcs and graphs of prevalence 
%%% for the cases of 0%, 5%, 10%, 15%, 20%, 30%, 50% shared staff
%%% choose scenario 0, 5, 10, 15, 20, 30, 50 for each of the avobe cases

Scenario=30;

load('NHdata.mat')

seed=2000;
sstart=1;
set(0,'defaultAxesFontSize',16)
NH1=56; % number of residents in NH1 
NH2=82; % number of residents in NH2
SNH1=25;% number of staff in NH1 
SNH2=40;% number of staff in NH2


if Scenario==0  % this is 0 precent shared nurses
A=S0;
elseif Scenario==5 % this is 5% precent shared nurses
A=S5;
elseif Scenario==10 % this is 10% precent shared nurses
A=S10;  
elseif Scenario==15 % this is 15% precent shared nurses
A=S15;  
elseif Scenario==20 % this is 20% precent shared nurses
A=S20;  
elseif Scenario==30 % this is 30% precent shared nurses
A=S30;  
elseif Scenario==50 % this is 50% precent shared nurses
A=S50;  
else
disp('Are you drunk?')
end
[VQ12,VQ32,VQ1,VQ3,upperWhisker,lowerWhisker,cycle1, Infected_res1, CIr1,  CIs1, PrevRes1, activepositive1, passivepositive1, ...
    cycle2, Infected_res2, CIr2,  CIs2, PrevRes2, activepositive2, passivepositive2]=NHsort(A,sstart,seed,Scenario);

%VQ1 is the vector of 1st quartiles for Nursing Home 1 model simulations
%VQ12 is the vector of 1st quartiles for Nursing Home 2 model simulations
%VQ3 is the vector of 3rd quartiles for Nursing Home 1 model simulations
%VQ32 is the vector of 3rd quartiles for Nursing Home 2 model simulations


x=1:91;
mCIr1=100*mean(CIr1,2)/NH1;  
mCIr2=100*mean(CIr2,2)/NH2;

mCIs1=100*mean(CIs1,2)/SNH1;  
mCIs2=100*mean(CIs2,2)/SNH2;
f0=figure;
plot(x,mCIr1,'-.b',x,mCIr2,':b',x,mCIs1,'--r',x,mCIs2,'-r','LineWidth',2)
grid on
xticks('manual')
xticks([5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90])
legend1 = legend('NH2 staff','NH1 staff', 'NH2 residents','NH1 residents');
set(legend1,...
    'Position',[0.158630957676186 0.640079370897913 0.308928564935923 0.251190469094685]);
ylabel('mean cumulative prevalence')
xlabel('days')
axis([1 91 0 100])

filename01 = ['MeanCumPrev ' num2str(Scenario) ' percent shared' '.tif'];
saveas(gcf,filename01)
filename02 = ['MeanCumPrev ' num2str(Scenario) ' percent shared' '.fig'];
saveas(gcf,filename02)
close(f0)

%%%% save the plots and outputs in the command window for each scenario
