%this is the main code for fitting the model to data

clear
clc
set(0, 'DefaultAxesFontSize', 16);
%load('elevenStates.mat')
%load('DZ11.mat') % this is the data of dates and zip codes for each state
load('thirteenStates.mat')
load('DZ13.mat') % this is the data of dates and zip codes for each state
% here are the variables for each state 
% column # 1= zipCode	
% column # 2= occupiedBeds
% column # 3= residentCovidCases	
% column # 4= staffCovidCases	
% column # 5= COVID19Mortality	
% column # 6= Prev Residents	
% column # 7= Prev Staff

% the contains file time series COVID-19 data of nursing homes in 
% four states during weeks of  5/24/2020 - 12/27/2020:
% 0=Alaska = 0% shared staff
% 1=Kentucky = 15% shared staff
% 2=Massachusetts = 20% shared staff
% 3=Nevada= 10% shared staff
% 4=Texas= 30-50% shared staff
% 5=AL= 0% shared staff
% 6=GA= 30% shared staff
% 7=LA= 30% shared staff
% 8=NH= 20% shared staff
% 9=OK= 20% shared staff
% 10=SC= 5% shared staff
% 11=ND= 5% shared staff

%%%%%%%%%%
% Main results:
% these numbers have worked: 1, 3, 5, 6,9, 10

State=12;
if State==1
A=Kentucky(:,6); %residents
B=Kentucky(:,7); % staff
DZ=DZkentucky; % date and zip code
elseif State==2
    A=Massachusetts(:,6); %residents
    B=Massachusetts(:,7); % staff
    DZ=DZMassachusetts; % date and zip code
    elseif State==3
        A=Nevada(:,6); %residents
        B=Nevada(:,7); % staff
        DZ=DZNevada; % date and zip code
        elseif State==4
            A=Texas(:,6); %residents
            B=Texas(:,7); % staff
            DZ=DZTexas; % date and zip code
            elseif State==5
            A=AL(:,6); %residents  Alabama
            B=AL(:,7); % staff
            DZ=DZAL; % date and zip code
                elseif State==6
            A=GA(:,6); %residents  Georgia 
            B=GA(:,7); % staff
            DZ=DZGA; % data and zip code
                    elseif State==7
            A=LA(:,6); %residents  Louisiana 
            B=LA(:,7); % staff
            DZ=DZLA; % date and zip code
                        elseif State==8
            A=NH(:,6); %residents New Hampshire
            B=NH(:,7); % staff
            DZ=DZNH; % date and zip code
                            elseif State==9
            A=OK(:,6); %residents  Oklahoma 
            B=OK(:,7); % staff
            DZ=DZOK; % date and zip code
                                elseif State==10
            A=SC(:,6); %residents  South Carolina 
            B=SC(:,7); % staff
            DZ=DZSC; % date and zip code
                                            elseif State==11
            A=ND(:,6); %residents  North Dakota 
            B=ND(:,7); % staff
            DZ=DZND; % date and zip code
              elseif State==12
            A=AK(:,6); %residents  Alaska
            B=AK(:,7); % staff
            DZ=DZAK; % date and zip code

% Specify the indices to exclude
A(609,1)=4;
A(610,1)=5;
B(609,1)=0.1;
B(610,1)=0.1;
A=A+.001;
B=B+0.001;
%             A12 = vec(~isnan(A));
%             B12 = vec(~isnan(B));
                   elseif State==13
            A=KY(:,6); %residents  Kentucky
            B=KY(:,7); % staff
            DZ=DZKY; % data and zip code
end

A(A>102)=100;
B(B>102)=100;
An=nonzeros(A);
Bn=nonzeros(B);
C=[DZ(:,1:2),A,B];% this is our data to work with
% WE WANT TO Find the unique rows of C based on the data in the first  column. 
% Specify three outputs to return the index vectors ia and ic.
[D, ia, ic] = unique(C(:,1));
%D returns the same data as in A, but with no repetitions. C is in sorted order.
% If A is a vector, then D = A(ia) and A = C(ic).
figure
s=0;% this will set week # s as the first week
for j=s:s+13%1:length(D)
xk=find(ic==j);
Zres=nonzeros(C(xk,3))
Zstaff=nonzeros(C(xk,4));
Resp(j-s+1)= mean(Zres);  % mean prev of residents for day j
Staffp(j-s+1)= mean(Zstaff); % mean prev of staff for day j
if j-s+1>1
% minResp(j-s,1)= min(Zres);  % mim prev of residents for day j
% minStaffp(j-s,1)= min(Zstaff); % min prev of staff for day j
maxResp(j-s,1)= max(Zres);  % max prev of residents for day j
% maxStaffp(j-s,1)= max(Zstaff); % max prev of staff for day j
q1 = quantile(Zres, 0.25); % First quartile (25th percentile)
q3 = quantile(Zres, 0.75); % Third quartile (75th percentile)
iqrValue = q3 - q1;        % Interquartile range (IQR)

% Compute whiskers
RESlowerWhisker(j-s,1) = max(min(Zres), q1 - 1.5 * iqrValue); % Lower whisker
RESupperWhisker(j-s,1) = min(max(Zres), q3 + 1.5 * iqrValue); % Upper whisker
end
Nr=length(Zres);
boxchart(Zres,'MarkerStyle','none','XData',j*ones(Nr,1));
hold on
end
ylabel('prevalence in residents (%)')
xlabel('weeks  5/24/2020 - 12/27/2020')
grid on
figure
for j=s:s+12%1:length(D)
xk=find(ic==j);
Zres=nonzeros(C(xk,3));
Zstaff=nonzeros(C(xk,4));
Resp(j-s+1)= mean(Zres);  % mean prev of residents for day j
Staffp(j-s+1)= mean(Zstaff); % mean prev of staff for day j
% if j-s+1==1
%     nZstaff=Zstaff;
% end
Ns=length(Zstaff);
boxchart(Zstaff,'MarkerStyle','none','XData',j*ones(Ns,1));
hold on
%nZstaff=mean(Zstaff)+nZstaff;
end
ylabel('prevalence in staff (%)')
xlabel('weeks  5/24/2020 - 12/27/2020')
ylim([0 100])
grid on
x=1:6.84:90; % converting weeks to days
figure
plot(x,(Resp),'or')
ylabel('mean prevalence in residents (%)')
xlabel('weeks  5/24/2020 - 12/27/2020')
grid on
figure
plot(x,(Staffp),'ob')
ylabel('mean prevalence of staff (%)')
xlabel('weeks  5/24/2020 - 12/27/2020')
grid on
figure
h1 = histogram(An);
hold on
h2 = histogram(Bn);
xlabel('prevalence (%)')
ylabel('probability')
legend ('staff','redident')
grid on
xlim([0 70])
h1.Normalization = 'probability';
h1.BinWidth = 2;
h2.Normalization = 'probability';
h2.BinWidth = 2;
Respmean=Resp';
