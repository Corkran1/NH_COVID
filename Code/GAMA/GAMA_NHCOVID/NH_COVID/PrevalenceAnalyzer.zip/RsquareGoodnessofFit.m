

%MATLAB Code for R² Computation with Resampling

% Example observed data and model simulations
observedData = randn(50, 1) * 10 + 50; % 50 observations
modelSimulations = randn(500, 1) * 12 + 52; % 500 simulations

% Initialize variables
nObs = length(observedData); % Number of observations
numResamples = 1000; % Number of resamples
rSquaredValues = zeros(numResamples, 1); % To store R² values for each resample

% Loop for resampling
for i = 1:numResamples
    % Randomly sample from model simulations to match the size of observed data
    sampledSimulations = datasample(modelSimulations, nObs, 'Replace', false);
    
    % Compute R² for the current resample
    % Total Sum of Squares (SST)
    sst = sum((observedData - mean(observedData)).^2);
    
    % Residual Sum of Squares (SSR)
    ssr = sum((observedData - sampledSimulations).^2);
    
    % R² formula
    rSquaredValues(i) = 1 - (ssr / sst);
end

% Summary statistics
meanRSquared = mean(rSquaredValues);
stdRSquared = std(rSquaredValues);

% Display results
fprintf('Average R² across resamples: %.3f\n', meanRSquared);
fprintf('Standard deviation of R²: %.3f\n', stdRSquared);

% Plot histogram of R² values
figure;
histogram(rSquaredValues, 20, 'Normalization', 'pdf', 'FaceColor', 'b');
xlabel('R² Values');
ylabel('Density');
title('Distribution of R² Across Resamples');
grid on;
